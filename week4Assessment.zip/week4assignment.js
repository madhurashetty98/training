

var pagenum = 1;
var pages = 1;
var trs = 0;
//display data
function display(n) {
    trs = trs + 1;
    $('#form').hide();
    pagenum = n;
    $.ajax({
        url: "https://reqres.in/api/users?page=" + pagenum,
        type: "GET",

        success: function (response) {
            $("tbody").children().remove();
            pages = response.total_pages;
            $.each(response.data, function (i, f) {
                console.log(f.first_name + f.last_name);
                var tblRow = "<tr id=" + f.first_name + "><td>" + f.first_name + f.last_name + "</td>" +
                    "<td>" + f.email + "</td>" +

                    "<td> <img src='" + f.avatar + "'/></td>" +
                    "<td><a class='edit'  id='ed' title='Edit'><i  style='color:#ffcc00' class='editbtn pointer material-icons'  data-toggle='modal' data-target='#editModal'>&#xE254;</i></a>  <i style='color:red' class='deletebtn pointer material-icons' data-toggle='modal' data-target='#exampleModal'>&#xE872;</i>  " +
                    "</td></tr>";
                $(tblRow).appendTo("#entrydata tbody");
               });
        }

    });
}

//toggle form 
function toggleform() {
    $('#form').toggle();
}


//add row
function addData() {


    trs = trs + 1;
    $('#form').toggle();
    var fname = document.getElementById('firstname').value;
    var emailid = document.getElementById('email').value;
    var lname = document.getElementById('lastname').value;
  
    $.ajax({
        url: "https://reqres.in/api/users?page=1",
        type: "POST",
        data: {
            first_name: fname,
            last_name: lname,
            email: emailid,
            avatar: ''
        },
        success: function (response) {
            console.log(response);
        }
    });
    var tblRow = "<tr id=" + (trs) + "><td>" + fname + lname + "</td>" +
        "<td>" + emailid + "</td>" +
        "<td> <img id='myImg' src='#' alt='your image' /></td>" +
        "<td><a class='edit'  id='ed' title='Edit'><i  style='color:#ffcc00' class='editbtn pointer material-icons'  data-toggle='modal' data-target='#editModal' >&#xE254;</i></a> <i style='color:red' class='deletebtn pointer material-icons'   data-toggle='modal' data-target='#exampleModal'>&#xE872;</i> " +
        "</td></tr>";
    $(tblRow).appendTo("#entrydata tbody");
    console.log("entered out");
    $(function () {

        $(":file").change(function () {
            console.log("entered l in");
            if (this.files && this.files[0]) {

                var reader = new FileReader();
                reader.onload = imageIsLoaded;
                reader.readAsDataURL(this.files[0]);
            }
        });
    });

    function imageIsLoaded(e) {
        console.log("entered");
        $('#myImg').attr('src', e.target.result);
    };


}


//delete record

$(document).on('click', '.deletebtn', function () {
    var dltrow = $(this).closest('tr');

    $(document).on('click', '#deletebtn', function () {

        dltrow.remove();
        return false;


    });


});

//edit data
$(document).on('click', '.editbtn', function () {
     document.getElementById('fname').value = '';
     document.getElementById('emailid').value='';
  document.getElementById('lname').value='';
  
    var dltrow = $(this).parents('tr');
    var name= dltrow.children("td")[0];
    var email= dltrow.children("td")[1];
  
   
    $(document).on('click', '.updatebtn', function () {
    var fname = document.getElementById('fname').value;
    var emailid = document.getElementById('emailid').value;
    var lname = document.getElementById('lname').value;
  
    name.innerHTML=fname+" "+lname;
    email.innerHTML=emailid;
        
    name="";
    email=""; 

    });
    

});


